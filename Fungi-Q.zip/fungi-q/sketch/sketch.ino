// SPDX-FileCopyrightText: Copyright (C) ARDUINO UNO Q
// SPDX-License-Identifier: MPL-2.0

#include <Arduino_RouterBridge.h>
#include <DHT.h>

// ========== CONFIGURACIÓN AM2301 ==========
#define DHTPIN 2
#define DHTTYPE DHT21
DHT dht(DHTPIN, DHTTYPE);

// ========== CONFIGURACIÓN RELÉ (Luz) ==========
#define RELAY_PIN 7

// ========== CONFIGURACIÓN HUMIDIFICADOR (1 pin - simula ground) ==========
#define HUMIDIFIER_PIN 8   // Pin que simula ground cuando está LOW

// Variables de estado
float temperature = 0.0;
float humidity = 0.0;
bool relayState = false;
bool humidifierState = false;  // false = apagado, true = encendido

unsigned long lastSensorRead = 0;
const unsigned long sensorInterval = 2000;

// ========== FUNCIONES DEL RELÉ (Luz) ==========
void setRelay(bool state) {
  relayState = state;
  digitalWrite(RELAY_PIN, relayState ? HIGH : LOW);
  Bridge.notify("relay_status", relayState);
  Bridge.notify("log_message", relayState ? "🔆 Luz ENCENDIDA" : "⚫ Luz APAGADA");
}

void toggleRelay() {
  setRelay(!relayState);
}

// ========== FUNCIONES DEL HUMIDIFICADOR ==========
void setHumidifier(bool state) {
  humidifierState = state;
  if (humidifierState) {
    // Simular ground: poner el pin en LOW
    digitalWrite(HUMIDIFIER_PIN, LOW);
    Bridge.notify("log_message", "💧 Humidificador ACTIVADO (máxima potencia)");
  } else {
    // Apagar: poner el pin en HIGH (o dejar flotando)
    digitalWrite(HUMIDIFIER_PIN, HIGH);
    Bridge.notify("log_message", "💧 Humidificador APAGADO");
  }
  Bridge.notify("humidifier_status", humidifierState);
}

void toggleHumidifier() {
  setHumidifier(!humidifierState);
}

void humidifierOn() {
  setHumidifier(true);
}

void humidifierOff() {
  setHumidifier(false);
}

// ========== SETUP ==========
void setup() {
  // === CONFIGURACIÓN RELÉ ===
  pinMode(RELAY_PIN, OUTPUT);
  digitalWrite(RELAY_PIN, LOW);
  
  // === CONFIGURACIÓN HUMIDIFICADOR ===
  pinMode(HUMIDIFIER_PIN, OUTPUT);
  digitalWrite(HUMIDIFIER_PIN, HIGH);  // Iniciar apagado (HIGH = no simula ground)
  
  // === INICIALIZAR SENSOR ===
  dht.begin();
  
  // === INICIALIZAR BRIDGE ===
  Bridge.begin();
  delay(2000);
  
  // === REGISTRAR FUNCIONES PARA PYTHON ===
  // Relé
  Bridge.provide("setRelay", setRelay);
  Bridge.provide("toggleRelay", toggleRelay);
  Bridge.provide("getRelayState", []() -> int { return relayState ? 1 : 0; });
  
  // Humidificador
  Bridge.provide("setHumidifier", setHumidifier);
  Bridge.provide("toggleHumidifier", toggleHumidifier);
  Bridge.provide("humidifierOn", humidifierOn);
  Bridge.provide("humidifierOff", humidifierOff);
  Bridge.provide("getHumidifierState", []() -> int { return humidifierState ? 1 : 0; });
  
  // === ENVIAR ESTADOS INICIALES ===
  Bridge.notify("relay_status", relayState);
  Bridge.notify("humidifier_status", humidifierState);
  
  Bridge.notify("log_message", "=== SISTEMA INICIADO ===");
  Bridge.notify("log_message", "Sensor AM2301 listo (pin D2)");
  Bridge.notify("log_message", "Relé listo (pin D7)");
  Bridge.notify("log_message", "Humidificador listo (pin D8) - Simula ground");
}

// ========== LOOP ==========
void loop() {
  unsigned long currentMillis = millis();
  
  if (currentMillis - lastSensorRead >= sensorInterval) {
    lastSensorRead = currentMillis;
    
    float h = dht.readHumidity();
    float t = dht.readTemperature();
    
    if (!isnan(h) && !isnan(t)) {
      temperature = t;
      humidity = h;
      
      Bridge.notify("temp_status_changed", String(temperature, 2).c_str());
      Bridge.notify("hum_status_changed", String(humidity, 2).c_str());
    } else {
      Bridge.notify("log_message", "⚠️ Error leyendo AM2301");
    }
  }
  
  delay(10);
}