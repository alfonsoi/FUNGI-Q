# SPDX-FileCopyrightText: Copyright (C) ARDUINO UNO Q
# SPDX-License-Identifier: MPL-2.0

from arduino.app_utils import App, Bridge
from arduino.app_bricks.web_ui import WebUI
import time

ui = WebUI()

# Variables de estado
current_temp = 0.0
current_hum = 0.0
relay_state = False
humidifier_state = False

# ========== HANDLERS ==========

def on_temp_status_changed(temp_str):
    global current_temp
    try:
        current_temp = float(temp_str)
        send_update()
    except ValueError:
        pass

def on_hum_status_changed(hum_str):
    global current_hum
    try:
        current_hum = float(hum_str)
        send_update()
    except ValueError:
        pass

def on_relay_status(status):
    global relay_state
    relay_state = bool(status)
    print(f"🔌 Luz: {'ENCENDIDA' if relay_state else 'APAGADA'}")
    ui.send_message("relay_update", {"state": relay_state})

def on_humidifier_status(status):
    global humidifier_state
    humidifier_state = bool(status)
    print(f"💧 Humidificador: {'ACTIVADO' if humidifier_state else 'APAGADO'}")
    ui.send_message("humidifier_update", {"state": humidifier_state})

def on_log_message(msg):
    print(f"📝 {msg}")

def send_update():
    ui.send_message("sensor_update", {
        "temperature": current_temp,
        "humidity": current_hum,
        "timestamp": time.time()
    })

# Registrar handlers
try:
    Bridge.provide("temp_status_changed", on_temp_status_changed)
    Bridge.provide("hum_status_changed", on_hum_status_changed)
    Bridge.provide("relay_status", on_relay_status)
    Bridge.provide("humidifier_status", on_humidifier_status)
    Bridge.provide("log_message", on_log_message)
    print("✅ Handlers registrados")
except RuntimeError as e:
    print(f"⚠️ Error: {e}")

# ========== API ==========

def toggle_relay():
    try:
        Bridge.call("toggleRelay")
        return {"success": True}
    except Exception as e:
        return {"success": False, "error": str(e)}

def toggle_humidifier():
    try:
        Bridge.call("toggleHumidifier")
        return {"success": True}
    except Exception as e:
        return {"success": False, "error": str(e)}

def humidifier_on():
    try:
        Bridge.call("humidifierOn")
        return {"success": True}
    except Exception as e:
        return {"success": False, "error": str(e)}

def humidifier_off():
    try:
        Bridge.call("humidifierOff")
        return {"success": True}
    except Exception as e:
        return {"success": False, "error": str(e)}

def get_full_status():
    return {
        "temperature": current_temp,
        "humidity": current_hum,
        "relay_state": relay_state,
        "humidifier_state": humidifier_state,
        "timestamp": time.time()
    }

# ========== API REST ==========
ui.expose_api("GET", "/api/status", get_full_status)
ui.expose_api("POST", "/api/relay/toggle", toggle_relay)
ui.expose_api("POST", "/api/humidifier/toggle", toggle_humidifier)
ui.expose_api("POST", "/api/humidifier/on", humidifier_on)
ui.expose_api("POST", "/api/humidifier/off", humidifier_off)

# ========== EVENTOS WEBSOCKET ==========

def on_connect(sid):
    print(f"🟢 Cliente conectado: {sid}")
    ui.send_message("sensor_update", {"temperature": current_temp, "humidity": current_hum}, room=sid)
    ui.send_message("relay_update", {"state": relay_state}, room=sid)
    ui.send_message("humidifier_update", {"state": humidifier_state}, room=sid)

def on_disconnect(sid):
    print(f"🔴 Cliente desconectado: {sid}")

ui.on_connect(on_connect)
ui.on_disconnect(on_disconnect)

print("=" * 50)
print("🌡️ Sistema de Control Ambiental con Cámara")
print("📍 Servidor: http://localhost:7000")
print("=" * 50)

App.run()